### Nginx image
This image is used to run nginx on the master.

#### Instructions
make




[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/images/nginx/README.md?pixel)]()
