# Kubernetes Dashboard
==============

Kubernetes Dashboard is a general purpose, web-based UI for Kubernetes clusters.
It allows users to manage applications running in the cluster, troubleshoot them,
as well as manage the cluster itself.

Learn more at: https://github.com/kubernetes/dashboard


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/dashboard/README.md?pixel)]()
