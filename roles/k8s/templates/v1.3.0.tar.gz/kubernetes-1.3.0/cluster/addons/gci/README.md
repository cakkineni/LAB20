Some addons need to be configured slightly differently when running on the
Google ContainerVM Image (GCI). This directory serves as a place to store yaml
manifests that need to differ slightly from the ones under
`cluster/saltbase/salt`.


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/gci/README.md?pixel)]()
